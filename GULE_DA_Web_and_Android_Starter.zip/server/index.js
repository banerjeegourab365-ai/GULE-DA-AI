import express from "express";

const app = express();
app.use(express.json({ limit: "1mb" }));

app.post("/api/chat", async (req, res) => {
  try {
    const { message, history = [], language = "Auto" } = req.body || {};
    if (!message?.trim()) return res.status(400).json({ error: "Please enter a message." });
    if (!process.env.GEMINI_API_KEY) {
      return res.status(503).json({ error: "AI is not connected yet. Add GEMINI_API_KEY to the server .env file." });
    }
    const contents = [
      ...history.slice(-12).map(m => ({
        role: m.role === "assistant" ? "model" : "user",
        parts: [{ text: String(m.text || "") }]
      })),
      { role: "user", parts: [{ text: message }] }
    ];
    const prompt = `You are GULE DA, a warm, funny, helpful Indian male AI companion. Be respectful and clear. Reply in ${language} if specified, otherwise match the user's language. ${JSON.stringify(contents)}`;
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${process.env.GEMINI_API_KEY}`,
      { method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }] }) }
    );
    const data = await response.json();
    if (!response.ok) return res.status(response.status).json({ error: data.error?.message || "AI request failed." });
    res.json({ reply: data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("") || "I couldn't form a reply. Try again." });
  } catch (e) {
    res.status(500).json({ error: "Server error. Please try again." });
  }
});

app.listen(process.env.PORT || 3001, () => console.log(`GULE DA server running on ${process.env.PORT || 3001}`));