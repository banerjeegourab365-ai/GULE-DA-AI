# GULE DA AI — Web + Android starter

This project contains one responsive web app and a Capacitor Android wrapper around the same app.

## Requirements
- Node.js 20+
- A Gemini API key
- Android Studio (for building the APK)

## Run the web app
1. Extract this ZIP.
2. Open a terminal in this folder and run `npm install`.
3. Copy `.env.example` to `.env` and add your Gemini API key.
4. Start the API server: `npm run server`.
5. In another terminal run `npm run dev`.
6. Open `http://localhost:5173`.

For production, configure your host to serve the Vite build and route `/api` to the Express server. Do not expose your Gemini key in browser code.

## Create the Android project
1. Run `npm install`.
2. Run `npm run build`.
3. Run `npx cap add android` (only the first time).
4. Run `npx cap sync android`.
5. Run `npx cap open android`.
6. In Android Studio choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated APK is available under `android/app/build/outputs/apk/debug/`.

## Notes
- Speech recognition and spoken replies use browser/device speech services. Voice availability and voice quality vary by Android device and installed language packs.
- The AI endpoint is a starter integration. Add rate limiting, authentication, usage limits, and production hosting before public release.
- The animated character is CSS artwork and can later be replaced with a custom illustrated/3D character and lip-sync animation.
