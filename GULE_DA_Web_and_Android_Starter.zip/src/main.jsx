import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Mic, Send, Volume2, VolumeX, Sparkles, Languages, MessageCircle } from "lucide-react";
import "./style.css";

function App() {
  const [messages, setMessages] = useState([{ role: "assistant", text: "আরে দাদা! আমি GULE DA 😎 তোমার AI বন্ধু। কী জানতে চাও?" }]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [speaking, setSpeaking] = useState(true);
  const [language, setLanguage] = useState("Auto");
  const [listening, setListening] = useState(false);
  const bottom = useRef(null);

  useEffect(() => bottom.current?.scrollIntoView({ behavior: "smooth" }), [messages, busy]);

  function say(text) {
    if (!speaking || !("speechSynthesis" in window)) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === "Bengali" ? "bn-IN" : language === "Hindi" ? "hi-IN" : "en-IN";
    utterance.rate = 0.96;
    window.speechSynthesis.speak(utterance);
  }

  async function send(text = input) {
    const value = text.trim();
    if (!value || busy) return;
    const next = [...messages, { role: "user", text: value }];
    setMessages(next); setInput(""); setBusy(true);
    try {
      const r = await fetch("/api/chat", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: value, history: messages, language })
      });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Could not connect to GULE DA.");
      setMessages([...next, { role: "assistant", text: data.reply }]);
      say(data.reply);
    } catch (e) {
      setMessages([...next, { role: "assistant", text: `একটু সমস্যা হচ্ছে: ${e.message}` }]);
    } finally { setBusy(false); }
  }

  function voiceInput() {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Voice input is not supported in this browser. Try Chrome."); return; }
    const rec = new SR(); rec.lang = language === "Bengali" ? "bn-IN" : language === "Hindi" ? "hi-IN" : "en-IN";
    rec.interimResults = false; rec.onstart = () => setListening(true);
    rec.onend = () => setListening(false);
    rec.onerror = () => setListening(false);
    rec.onresult = e => send(e.results[0][0].transcript);
    rec.start();
  }

  return <main className="shell">
    <header><div className="brand"><div className="logo">গু</div><div><b>GULE DA</b><small>YOUR DESI AI BUDDY</small></div></div>
      <button className="sound" onClick={() => setSpeaking(!speaking)} aria-label="Toggle voice">{speaking ? <Volume2/> : <VolumeX/>}</button></header>
    <section className="hero">
      <div className="orbit orbit1"></div><div className="orbit orbit2"></div>
      <div className="avatar"><div className="hair"></div><div className="face"><div className="brow b1"></div><div className="brow b2"></div><div className="glasses"><i></i><i></i></div><div className="eyes"><i></i><i></i></div><div className="nose"></div><div className="moustache"></div><div className="smile"></div></div><div className="body"><span>G</span></div></div>
      <div className="status"><span></span> ONLINE • READY TO CHAT</div>
      <h1>কী খবর দাদা?</h1><p>Your friendly neighbourhood AI is here.</p>
    </section>
    <section className="chat">
      <div className="chatTitle"><span><MessageCircle size={17}/> CHAT WITH GULE DA</span><label><Languages size={15}/><select value={language} onChange={e=>setLanguage(e.target.value)}><option>Auto</option><option>Bengali</option><option>Hindi</option><option>English</option></select></label></div>
      <div className="messages">{messages.map((m,i)=><div key={i} className={`msg ${m.role}`}><div className="bubble">{m.text}</div></div>)}{busy && <div className="msg assistant"><div className="bubble typing">GULE DA is thinking<span>•••</span></div></div>}<div ref={bottom}/></div>
      <div className="composer"><button className={`mic ${listening?"active":""}`} onClick={voiceInput}><Mic size={20}/></button><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()} placeholder="Ask GULE DA anything..."/><button className="send" onClick={()=>send()} disabled={busy||!input.trim()}><Send size={19}/></button></div>
      <div className="hint"><Sparkles size={13}/> Bengali • Hindi • English</div>
    </section>
    <footer>Made with ❤️ for curious minds</footer>
  </main>;
}
createRoot(document.getElementById("root")).render(<App/>);